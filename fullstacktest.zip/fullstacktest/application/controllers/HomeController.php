<?php
ob_start();
defined('BASEPATH') or exit('No direct script access allowed');
error_reporting(0);
class HomeController extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('HomeModel');
  }

  public function index()
  {   
        $data['getallrecords'] = $this->HomeModel->getallrecords();
        $data['getallrecord'] = $this->HomeModel->getallrecord();
       $this->load->view('index',$data);
  }


  public function tabdata()
  {
    $data['gettab'] = $this->HomeModel->gettab();
    $data['gettabname'] = $this->HomeModel->gettabname();
    $data['gettabrecords'] = $this->HomeModel->gettabrecords();

    $this->load->view("tabdata",$data);
  }

  public function addtab()
  {
      if ($this->input->post('submit', TRUE)) {            
       
            $data= array(
                        'tab_name'=>$this->input->post('tab_name')
                      );

             if ($this->db->insert('tbl_tab', $data)) {
               echo '<script>alert("Tab Added Successfully.!");window.location.href="tabdata";</script>';
            }
            else{
             echo '<script>alert("Error.!! Try Again");window.location.href="tabdata";</script>';
            }

     
    }

    $this->load->view('tabdata');
  }
   public function tabdataup($tid)
    {
      //echo $tid;
      $data['tabup'] = $this->HomeModel->tabup($tid);
     //// print_r($data['tabup']);
     // die;
      $this->load->view('tabdataup',$data);
    }
  

   public function tabup($tid)
    {
      echo $tid;
      $data['tabup'] = $this->HomeModel->tabup($tid);
      print_r($data['tabup']);
      die;
      $this->load->view('tabup',$data);
    }

    public function updatetab()
    {
       $post_data=$this->input->post();
      $data['res']=$this->HomeModel->updatetab($post_data);
       echo '<script>alert("Tab updated Successfully.!");window.location.href="tabdata";</script>';
    
    $this->load->view('tabdata');
    }

     public function deletetab($tid)
    {
     $res= $this->HomeModel->deletetab($tid);
       echo '<script>alert("Tab Deleted Successfully.!");window.location.replace("http://localhost/fullstacktest/tabdata");</script>';
           
  
    }


    public function addtabdetails()
    {
       if (isset($_POST['submit'])) 
    {
      
       $post_data = $this->input->post();

 // print_r($post_data);
 // die;
    //load upload class library with configuration
      $config =  array(
                'upload_path'     => 'upload/',
                'allowed_types'   => 'png|PNG|jpg|jpeg|JPG|JPEG|gif|GIF|bmp|BMP',
                'overwrite'       => TRUE,
                'max_size'        => '2048000',  // Can be set to particular file size
                //'max_height'      => '768',
                //'max_width'       => '1024'   //'file_name'   => strtotime('now')  
              );    
      $this->load->library('upload', $config);
          
      
      if($this->upload->do_upload('tabdetails_image'))
      {
        if(isset($post_data['tabdetails_image']) && !empty($post_data['tabdetails_image']) && file_exists('upload/'.$post_data['tabdetails_image']))
          unlink('upload/'.$post_data['tabdetails_image']);
        $upload_data = $this->upload->data();
        $post_data['tabdetails_image'] = $upload_data['file_name'];
      }
      else
      {
        $post_data['tabdetails_image'] = $post_data['tabdetails_image'];
      }
  




      $post_data= array(

        'tbl_tab_id' =>$this->input->post('tbl_tab_id'),
         'tabdetails_desc' => $this->input->post('tabdetails_desc'),
        'tabdetails_image' => $post_data['tabdetails_image']
       
      
         


      );
       $result = $this->db->insert("tbl_tabdetails",$post_data);

       if($result)
       {
          echo '<script>alert(" Data Added Successfully.!");window.location.href="tabdata";</script>';
       }
       else
       {
            echo '<script>alert("Error.!");window.location.href="tabdata";</script>';
       }
          }
    }


      public function deletedata($id)
    {
     $res= $this->HomeModel->deletedata($id);
       echo '<script>alert("Record Deleted Successfully.!");window.location.replace("http://localhost/fullstacktest/tabdata");</script>';           
  
    }

      public function tabrecup($id)
    {
      $data['tabrecup'] = $this->HomeModel->tabrecup($id);
      //print_r($data['authorup']);
      $this->load->view('tabrecup',$data);
    }

    public function allrecup($id){
       $data['tabrecup'] = $this->HomeModel->tabrecup($id);
      //print_r($data['authorup']);
      $this->load->view('allrecup',$data);
    }

    public function updatetabrec()
    {
       $post_data=$this->input->post();
      $data['res']=$this->HomeModel->updatetabrec($post_data);
       echo '<script>alert("Tab updated Successfully.!");window.location.href="tabdata";</script>';
    
    $this->load->view('tabdata');
    }


}

?>