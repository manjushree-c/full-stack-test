<?php 
class HomeModel extends CI_Model
{
  function __construct()
  {
    $this->load->database();
  }

  public function gettab()
    {
      $this->db->select('*');
      $this->db->from('tbl_tab');
      $res=$this->db->get();
      return $res->result_array();
    }

    public function gettabname()
    {
      $this->db->select('tbl_tab_id,tab_name');
      $this->db->from('tbl_tab');
      $this->db->order_by('tab_name','asc');
      $res=$this->db->get();
      return $res->result_array();
    }

     public function tabup($tid)
    {
      $this->db->select('*');
      $this->db->from('tbl_tab');
      $this->db->where('tbl_tab_id',$tid);
      $res=$this->db->get();
      return $res->result_array();
    }

     public function updatetab($post_data)
    {
        extract($post_data);
        // print_r($post_data);
        // die;


        $tid=$_POST['tbl_tab_id'];
        $input_data=array(

        'tab_name'=>$this->input->post('tab_name')
       

        );
        $where=array('tbl_tab_id'=>$tid,

        );
        $this->db->where($where);
        $this->db->update('tbl_tab',$input_data);
    }

    public function deletetab($tid)
    {
      $tble=array('tbl_tab');
      $this->db->where('tbl_tab_id', $tid);
      $this->db->delete($tble);
    }

     public function gettabrecords()
    {
        $this->db->select('*');
        $this->db->from('tbl_tabdetails td');
        $this->db->join('tbl_tab t',"td.tbl_tab_id = t.tbl_tab_id","inner");
        $res=$this->db->get();
      return $res->result_array();
                     
    }

    public function deletedata($id)
    {
         $tble=array('tbl_tabdetails');
      $this->db->where('tbl_tabdetails_id', $id);
      $this->db->delete($tble);
    }

    public function tabrecup($id)
    {
      $this->db->select('*');
      $this->db->from('tbl_tabdetails td');
        $this->db->join('tbl_tab t',"td.tbl_tab_id = t.tbl_tab_id","inner");
        $this->db->where('tbl_tabdetails_id', $id);
      $res=$this->db->get();
      return $res->result_array();
    }

     public function updatetabrec($post_data)
    {
        extract($post_data);
         // print_r($post_data);
         // die;
          if($post_data['tabdetails_image']!==''){
          $config =  array(
                'upload_path'     => 'upload/',
                'allowed_types'   => 'png|PNG|jpg|jpeg|JPG|JPEG|gif|GIF|bmp|BMP',
                'overwrite'       => TRUE,
                'max_size'        => '2048000',  // Can be set to particular file size
                //'max_height'      => '768',
                //'max_width'       => '1024'   //'file_name'   => strtotime('now')  
              );    
      $this->load->library('upload', $config);
          
      // upload Cover Pic
      if($this->upload->do_upload('tabdetails_image'))
      {
        if(isset($post_data['tabdetails_image']) && !empty($post_data['tabdetails_image']) && file_exists('upload/'.$post_data['tabdetails_image']))
          unlink('upload/'.$post_data['tabdetails_image']);
        $upload_data = $this->upload->data();
        $post_data['tabdetails_image'] = $upload_data['file_name'];
      }
      else
      {
        $post_data['tabdetails_image'] = $post_data['tabdetails_image'];
      }


      
    
        }
        else{
          $post_data['tabdetails_image'] = $_POST['tabdetails_image1'];
        }

        $id=$_POST['tbl_tabdetails_id'];
        $input_data=array(

        'tbl_tab_id' =>$this->input->post('tbl_tab_id'),
         'tabdetails_desc' => $this->input->post('tabdetails_desc'),
        'tabdetails_image' => $post_data['tabdetails_image']

        );
        $where=array('tbl_tabdetails_id'=>$id,

        );
        $this->db->where($where);
        $this->db->update('tbl_tabdetails',$input_data);
    }


      public function getallrecords()
    {
         $this->db->select('*');
      $this->db->from('tbl_tab');
      // $this->db->order_by('tbl_tab_id','asc');
      $res=$this->db->get();
      return $res->result_array();
                     
    }

    public function getallrecord()
    {
         $this->db->select('*');
      $this->db->from('tbl_tab');
      // $this->db->order_by('tbl_tab_id','asc');
      $res=$this->db->get();
      return $res->result_array();
                     
    }

     public function allrecords($id)
    {
        $this->db->select('*');
        $this->db->from('tbl_tabdetails td');
        $this->db->join('tbl_tab t',"td.tbl_tab_id = t.tbl_tab_id","inner");
        $this->db->where('t.tbl_tab_id',$id);
        $res=$this->db->get();
      return $res->result_array();
                     
    }
 
}
  ?>