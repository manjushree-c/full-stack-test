<!DOCTYPE html>
<html lang="en">
<head>

	<!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   
    <meta name="keywords" content="" />
 
    <meta name="description" content="" />


    <!-- PAGE TITLE HERE -->
   
    
    <title>Tab Data</title>
        
    
    <!-- MOBILE SPECIFIC -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <?php include('common-css.php');?>

    <style type="text/css">
        body {
  padding : 10px ;
  
}



#exTab2 h3 {
  color : #333;
 /* background-color: #428bca;*/
  padding : 5px 15px;
  margin-top: 5px;
}

#exTab2 p {
  color : #333;
 /* background-color: #428bca;*/
  padding : 5px 15px;
  margin-top: 5px;
}








    </style>
</head>

<body  id="bg">

	<div class="page-wraper"> 
       	
      
        
        <!-- CONTENT START -->
       
<div class="container"><h1><a href="<?php echo base_url()?>index">Home</a> </h1></div>
<hr></hr>


<div class="container"><h2>Tab Data</h2></div>

<div id="exTab2" class="container"> 
<ul class="nav nav-tabs">
            <li class="active">
        <a  href="#1" data-toggle="tab">Add Tab</a>
            </li>
            <li><a href="#2" data-toggle="tab">Tab Data</a>
            </li>
            <li><a href="#3" data-toggle="tab">Add Tab Details Data</a>
            </li>
             <li><a href="#4" data-toggle="tab">Tab Detail Records</a>
            </li>

        </ul>

            <div class="tab-content ">
             
              <div class="tab-pane active" id="1">
        
          <div class="wt-box">
                        <div class="bg-white block-shadow radius-md  p-a30">
                            <form  method="POST" action="<?php echo base_url()?>addtab">
                        
                            <div class="row">
                                <div class="col-md-4">
                                    <label>Tab Name:<font color="red">*</font></label>
                                </div>
                               <div class="col-md-6">
                                    <div class="form-group">
                                        <input name="tab_name" type="text" required class="form-control bg-gray bdr-none" placeholder="Tab Name" required="" pattern="[a-zA-Z]*" title="Only Alphabets allowed" >
                                    </div>
                                </div>



                                <div class="col-md-12 text-right">
                                    <button name="submit" type="submit" value="Submit" class="site-button  m-r15">Submit</button>
                                  
                                </div>

                            </div>

                        </form>
                        </div>
                    </div> 
                </div>
                
                <div class="tab-pane" id="2">
 <h3>Tab List</h3></h3>


            <table  class="table table-striped table-responsive-sm">
              <th>Id</th>
              <th>Tab Name</th>
              
              <th>Date Created</th>
              <th>Action</th>

              <?php 
                foreach ($gettab as $gettab) {
                ?>
              <tr>
                <td><?php echo $tid=$gettab['tbl_tab_id'];?></td>
                <td><?php echo $gettab['tab_name'];?></td>
                
                <td><?php echo $gettab['tabDateCreated'];?></td>
                <td><a href="<?php echo base_url()?>tabdataup/<?php echo $tid?>">Update</a> / <a href="<?php echo base_url()?>deletetab/<?php echo $tid?>">Delete</a></td>
              </tr>
                <?php }?>
          </table>

            </div>
        
        <div class="tab-pane" id="3">
          <h3>Add Tab Details</h3>

          <div class="wt-box">
                        <div class="bg-white block-shadow radius-md  p-a30">
                            <form  method="POST" action="<?php echo base_url()?>addtabdetails" enctype="multipart/form-data">
                        
                            <div class="row">
                                <div class="col-md-3">
                                    <label>Tab name:<font color="red">*</font></label>
                                </div>
                               <div class="col-md-8">
                                    <div class="form-group">
                                      <select name="tbl_tab_id"  class="form-control bg-gray bdr-none">
                                <?php 
                                if(isset($gettabname) && !empty($gettabname)){
                                    foreach ($gettabname as $gettabname) {
                                       
                                ?>
                                 <option value="<?php echo $gettabname['tbl_tab_id']?>" ><?php echo $gettabname['tab_name']?></option>

                                 <?php }}?>
                             </select>
                                    </div>
                                </div>


                                <div class="col-md-3">
                                    <label>Tab Description:<font color="red">*</font></label>
                                </div>
                                 <div class="col-md-8">
                                     <div class="form-group">
                      <textarea name="tabdetails_desc" rows="2" cols="50"  class="form-control bg-gray bdr-none">

                          </textarea>

                         </div>
                     </div>

                        <div class="col-md-3">
                                    <label>Tab Image:<font color="red">*</font></label>
                                </div>
                                 <div class="col-md-8">
                                     <div class="form-group">
                                <input type="file" name="tabdetails_image" required="" accept="image/*">

                         </div>
                     </div>


                                <div class="col-md-12 text-right">
                                    <button name="submit" type="submit" value="Submit" class="site-button  m-r15">Submit</button>
                                  
                                </div>

                            </div>

                        </form>
                        </div>
                    </div> 
                </div>

    <div class="tab-pane" id="4">
         <?php if(isset($gettabrecords) && !empty($gettabrecords)){

                ?>
          <h3>Tab Records</h3> 


            <table  class="table table-striped table-responsive-sm">
              <th>Tab Id</th>
              <th>Tab Name</th>
              <th>Tab Description</th>
              <th>Tab Image</th>
              <th>Action</th>

              <?php 
                foreach ($gettabrecords as $gettabrecords) {
                ?>
              <tr>
                <?php $id=$gettabrecords['tbl_tabdetails_id'];?>
                <td><?php echo $tid=$gettabrecords['tbl_tab_id'];?></td>
                <td><?php echo $gettabrecords['tab_name'];?></td>
              <td>         <?php echo $gettabrecords['tabdetails_desc'];?>      </td>
                <td>     <img src="<?php echo base_url()?>upload/<?php echo $gettabrecords['tabdetails_image'];?>" style="width: 200px;height: auto;">            </td>
               
               
              
                <td><a href="<?php echo base_url()?>allrecup/<?php echo $id;?>">Update</a> / <a href="<?php echo base_url()?>deletedata/<?php echo $id;?>">Delete</a></td>

              </tr>
                <?php }}?>
          </table>
          
            </div>

        
            </div>
  </div>

<hr></hr>





<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    
        
    
 	</div>



</body>
 
<?php include('common-js.php');?>

</html>
